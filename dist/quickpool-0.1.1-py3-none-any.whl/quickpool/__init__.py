from .quickpool import ProcessPool, ThreadPool, update_and_wait

__version__ = "0.1.1"
