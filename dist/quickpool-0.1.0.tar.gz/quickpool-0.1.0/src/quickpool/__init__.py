from .quickpool import ProcessPool, ThreadPool

__version__ = "0.1.0"
