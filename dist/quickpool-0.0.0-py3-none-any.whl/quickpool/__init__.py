from .quickpool import ProcessPool, ThreadPool

__version__ = "0.0.0"
